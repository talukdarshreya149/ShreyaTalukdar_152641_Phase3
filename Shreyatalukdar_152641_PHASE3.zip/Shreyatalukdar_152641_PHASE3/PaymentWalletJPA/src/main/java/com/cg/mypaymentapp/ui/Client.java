package com.cg.mypaymentapp.ui;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client {
	
	static WalletService service=new WalletServiceImpl();
    static int choice1=0;
	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {

	boolean check;
	Scanner scanner=new Scanner(System.in);
	
	int choice=0;
	
	  do {
		
		  printDetails();
		System.out.println("Enter choice");
		choice=scanner.nextInt();
		
		switch (choice) {
		case 1:
			
			System.out.println("Enter Mobile No");
			String mobileNo=scanner.next();
			System.out.println("Enter Name");
			String name=scanner.next();
			System.out.println("Enter Balance");
			BigDecimal balance=scanner.nextBigDecimal();
			
			Customer customer=new Customer();
		
			try {
				
				if(service.inputValidation(name, mobileNo)) {
					
			customer.setName(name);
			customer.setMobileNo(mobileNo);
				}
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
			customer.setWallet(balance);
			
			service.createAccount(customer);
			System.out.println("Account Created");
			
			break;
		
		case 2:
			// System.out.println("Enter Name");
			// String name1=scanner.next();
			try {
				
			System.out.println("Enter receiver MobileNo");
			String mobNo=scanner.next();
			
			
				if(service.mobileValidation(mobNo)) {
					
					check=service.checkMobile(mobNo);
					if(check==true) {
				selectOption(mobNo);		
			}
				else {
				System.out.println("Mobile No doesnt exist");
			}
				
			}
		}catch(Exception e) {
				 	
					System.out.println(e.getMessage());
				}
		break;
		
     case 3:
	  
	  System.exit(0);
	
	  break;
		}
		
	} while(choice!=3);
		
	}
	
	public static void selectOption(String mobNo) throws InvalidInputException, InsufficientBalanceException {
		
		do {
			 printDetails1();
			
			System.out.println("Enter choice");
			choice1=scanner.nextInt();
			
			switch (choice1) {
			
			case 1:
				Customer cust1=service.showBalance(mobNo);
				System.out.println(cust1);
				break;
			
			case 2:
				  try {
				System.out.println("Enter mobile No");
				
					  String mobNoR=scanner.next();
		  if(service.mobileValidation(mobNoR)) {
			
			  if(service.checkMobile(mobNoR)) {
				  System.out.println("Enter the Amount to be transfered");
				  BigDecimal amtTransfer=scanner.nextBigDecimal();
				 
				  if(service.transferValidation(amtTransfer, mobNo)) {
			
					  Customer custReceiver=service.fundTransfer(mobNo, mobNoR, amtTransfer);
	                  System.out.println(custReceiver);  
				  }
				  
		  }  else {
			  System.out.println("Mobile No do not exist");
		         }
		  }
	  } catch(InsufficientBalanceException e){	  
	 
		  System.out.println(e.getMessage());
	  }
	    catch (InvalidInputException e) {
		System.out.println(e.getMessage());
	}
	   
	  break;
		
 case 3:
				
	  System.out.println("Enter Amount to be deposited");
	  BigDecimal amount=scanner.nextBigDecimal();
	  Customer cust=service.depositAmount(mobNo, amount);
	  System.out.println(cust);
	  
	  break;
	  
  case 4:
	  
	  System.out.println("Enter Amount to be withdrawn");
	  BigDecimal amount1=scanner.nextBigDecimal();
	 
	  try {
		  if(service.balanceValidation(amount1, mobNo)) {
			  	  
	  Customer cust2=service.withdrawAmount(mobNo, amount1);
	  System.out.println(cust2);
		  }
	  } catch(Exception e) { 
	  System.out.println(e.getMessage());  
	  }	  
	  break;
	  
  case 5:
	  
	  ArrayList<String> allData=null;
	  allData=service.printTransactions(mobNo);
	  
	  for(String string :allData) {
		  System.out.println(string);
	    }
	  
	  break;
	  
  case 6:
	 
	  new Client();
	  	  break;
  }			
	} while( choice1!=6);
			

	}
	
	
	public static void printDetails() {
		
		System.out.println("***************Hello User*****************");
		
		System.out.println("             1.  Create  Account           ");
		System.out.println("             2.  Log In                    ");
		System.out.println("             3.  Exit                      ");
	}
	
	
	public static void printDetails1() {
		
		System.out.println("----------------Payment Wallet-------------");
		
		System.out.println("               1. Show Balance             ");
		System.out.println("               2. Fund Transfer            ");
		System.out.println("               3. Deposit Amount           ");
		System.out.println("               4. Withdraw Amount           ");
		System.out.println("               5. Print Transaction        ");
		System.out.println("               6. LogOut                   ");
		
	}

}
