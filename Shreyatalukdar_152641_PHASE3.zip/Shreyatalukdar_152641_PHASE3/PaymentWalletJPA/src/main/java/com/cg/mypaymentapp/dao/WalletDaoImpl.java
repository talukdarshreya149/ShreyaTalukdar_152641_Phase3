package com.cg.mypaymentapp.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.persistence.EntityManager;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.util.DBUtil;

public class WalletDaoImpl implements WalletDao {
	
	static Connection con = null;
	
	private EntityManager entityManager;
	
	public WalletDaoImpl() {
		
		entityManager=JPAUtil.getEntityManager();
		
		try {
			con = DBUtil.getConnect();
		} catch (Exception e) {
			
		}
	}
	
	public String save(Customer customer) {
		
		entityManager.persist(customer);
		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) throws InvalidInputException {
		
		Customer customer=entityManager.find(Customer.class,mobileNo);
		return customer;
				
	}

	public boolean checkMobile(String mobileNo) {
		boolean check=false;
		if(entityManager.find(Customer.class, mobileNo) != null) 
			check=true;
		
		else {
			    check=false;
		}
   return check;
	}

	public void addTransaction(String mobileNo, String transaction) {

		try{
		
		String sql= "INSERT INTO TRANSACTION VALUES(?,?)";	
        PreparedStatement pstmt = con.prepareStatement(sql);
		
        pstmt.setString(1, mobileNo);
		pstmt.setString(2, transaction);
        pstmt.executeUpdate();
		
		} catch(Exception e) {
			
			}
	}
 
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputException {
		
		ArrayList<String> transactionList=new ArrayList<String>();
		String sql="SELECT * FROM TRANSACTION WHERE MOBILE= ?";
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			
			ResultSet res=pstmt.executeQuery();
			
			if(res.next()) { 
				
				while(res.next()) {
					transactionList.add(res.getString(2));
				}
			
			} else {
				
				throw new InvalidInputException("Customer not found");
			}
		} catch(Exception e) {
			
		}
		return transactionList;
	}

	
	public void updatewallet(Customer customer) {
		entityManager.merge(customer);
	}

	
	

}

